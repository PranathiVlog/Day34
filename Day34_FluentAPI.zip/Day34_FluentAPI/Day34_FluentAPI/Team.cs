﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34_FluentAPI
{
    class Team
    {
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public int Size { get; set; }

        //navigation 
        //a team can have 0 or more emp
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
