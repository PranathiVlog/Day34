﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Day34_FluentAPI
{
    class MyDbContext : DbContext
    {
        public MyDbContext() : base("name=mydb")
        {

        }

        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<EmployeeDetails> EmployeeDetails { get; set; }
        public virtual DbSet<Project> Projects { get; set; }
        public virtual DbSet<Team> Teams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            #region Enity Configurations

            // Totable -> configure/set table name in sl scripts
            modelBuilder.Entity<Department>().ToTable("Dept");

            // haskey will be primary key usually the table department has
            // DeptId instead of DepartmentId hence we need to Configure it as Primary Key
            modelBuilder.Entity<Department>().HasKey(d => d.DeptId);

            //the emp details has the key empid thats not following domain class rules
            //hence making this as pk explicitly
            modelBuilder.Entity<EmployeeDetails>().HasKey(ed => ed.EmployeeId);

            #endregion

            #region PropertyConfigurations
            //property -> emp id will be disabled wrt autoincrement
            modelBuilder.Entity<Employee>().Property(e => e.employeeId).HasDatabaseGeneratedOption
                (DatabaseGeneratedOption.None);

            //empname will be changed to ename (renaming column)
            //isrequired making is not null
            modelBuilder.Entity<Employee>().Property(e => e.EmpName).HasColumnName("Ename")
                                                                            .IsRequired()
                                                                            .HasColumnType("varchar")
                                                                            .HasMaxLength(50);


            modelBuilder.Entity<Employee>().Property(e => e.phone).IsRequired().HasMaxLength(10);

            #endregion

            #region Association Configuration

            //one to one relationship Employee  -->Employeedetails
                               //each emp has 0/1 empdetails                       every empdetail should have 1 employee
            modelBuilder.Entity<Employee>().HasOptional(e =>e. EmployeeDetails).WithRequired(ed=>ed.Employee);

            //dept ->Emp 1 to many
            //Has many ->1 departmnt has many emps hasmany(d=>d.emp)
            //WithRequired(e=>e.Department) each emp must and should have 1 dept(with req)
            //HasForeignKey(e=>e.DeptId) Employee table DeptId=>foreign key
            modelBuilder.Entity<Department>().HasMany(d => d.Employees).WithRequired(e => e.Department).HasForeignKey(e => e.DeptId);


            //one to many relationship (1....*)
            //team and employee
            //.Hasmany (t=> t.employees)=====each team can have more emps
            //WithOptional(e=>e.Team)====employee may/may not have a team
            //HasFk(e=>e.TeamId)====employee fk is teamid
            modelBuilder.Entity<Team>().HasMany(t => t.Employees).WithRequired(e => e.Team).HasForeignKey(e => e.TeamId);


            //(Employee ---- Project ) Many to many
            //create a table called as "Employee_Proj"
            // it has 2 columns 1--> EmployeeId(Employee table)
            //                  2--> ProjectId(Project table)
            modelBuilder.Entity<Employee>().HasMany(e => e.Projects)
              .WithMany(p => p.Employees)
              .Map(ep =>
              {
                  ep.MapLeftKey("EmployeeId");
                  ep.MapRightKey("ProjectId");
                  ep.ToTable("Employee_Proj");
              });

            #endregion
        }

    }
}