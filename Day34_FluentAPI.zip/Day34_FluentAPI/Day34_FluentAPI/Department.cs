﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34_FluentAPI
{
    class Department
    {
        public int DeptId { get; set; }
        public string Departmentname { get; set; }
       
        //navigation properties
        //one dept many employees

        public virtual ICollection<Employee>Employees { get; set; }



    }
}
