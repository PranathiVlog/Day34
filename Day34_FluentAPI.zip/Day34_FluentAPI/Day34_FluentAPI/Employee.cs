﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34_FluentAPI
{
    class Employee
    {
        public int employeeId { get; set; }
        public string EmpName { get; set; }
        public float Salary { get; set; }
        public string email { get; set; }
        public string phone { get; set; }

        //to reference dept
        public int DeptId { get; set; }

        //to reference teamid
        public int? TeamId { get; set; }

        //navigation
        //one employee has one department associated
        public virtual Department Department { get; set; }
        //one employee will have 1 employee details associated

        public virtual EmployeeDetails EmployeeDetails { get; set; }
        //1 employee can be associated with 1 team

        public virtual Team Team { get; set; }

        //1 emp can be associated with multiple projects 
        public virtual ICollection<Project> Projects { get; set; }
    }
}
