﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34_FluentAPI
{
    class Project
    {
        public int ProjectId { get; set; }
        public string Projectname { get; set; }
        public string domain { get; set; }

        //navigation
        //each proj can have 1 or more group 

        public virtual ICollection<Employee> Employees { get; set; }

    }
}
